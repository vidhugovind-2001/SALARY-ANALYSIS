create database milestone_new;
use milestone_new;
create table salary_survey_1(id int auto_increment primary key, age_range varchar(200),
industry varchar(200),job_title varchar(200),total_salary int,annual_salary int,compensation int,currency varchar(100),
country varchar(100),state varchar(100),city varchar(100),overall_experience varchar(100),
expreince_in_field varchar(100),education varchar(100),gender varchar(100));