SELECT * FROM milestone_new.salary_survey_1;
use milestone_new;
set sql_safe_updates=0;
update salary_survey_1
set education=replace(education,'Some College','College Degree')
where education like '%Some College%';
set sql_safe_updates=1;
#1.Average Salary by Industry and Gender
select industry,avg(total_salary/ExchangeRate) as avg_salary,gender from milestone_new.salary_survey_1
join exchangerates on salary_survey_1.currency=exchangerates.currency
group by gender,industry
order by avg_salary desc;
select gender,avg(total_salary/ExchangeRate) as avg_salary from salary_survey_1
join exchangerates on salary_survey_1.currency=exchangerates.currency
group by gender
order by avg_salary desc;

#2.Total Salary Compensation by Job Title
select job_title,avg(total_salary/ExchangeRate) as avg_salary from salary_survey_1
join exchangerates on salary_survey_1.currency=exchangerates.currency
group by job_title order by avg_salary desc;

#3.Salary Distribution by Education Level
select education,avg(total_salary/ExchangeRate) as avg_salary,
min(total_salary/ExchangeRate) as min,
max(total_salary/ExchangeRate) as max 
from salary_survey_1 join exchangerates on salary_survey_1.currency=exchangerates.currency
group by education order by avg_salary desc;

#4.Number of Employees by Industry and Years of Experience
select industry,count(job_title) as employee_count,overall_experience from salary_survey_1
group by industry,overall_experience ;

#5- with help of cht gpt.dbt on median
WITH salary_data AS (
    SELECT 
        age_range, 
        gender, 
        AVG(total_salary) AS avg_salary
    FROM salary_survey_1
    GROUP BY age_range, gender
), ranked_salaries AS (
    SELECT 
        age_range, 
        gender, 
        avg_salary,
        ROW_NUMBER() OVER (PARTITION BY age_range, gender ORDER BY avg_salary) AS row_num,
        COUNT(*) OVER (PARTITION BY age_range, gender) AS total_rows
    FROM salary_data
)
SELECT 
    age_range, 
    gender, 
    AVG(avg_salary) AS median_salary
FROM ranked_salaries
WHERE row_num IN (FLOOR((total_rows + 1) / 2) + 1, CEIL((total_rows + 1) / 2))
GROUP BY age_range, gender;

#6.Job Titles with the Highest Salary in Each Country
select country,job_title,total_salary from 
(select country,job_title,total_salary,rank() over (partition by country order by total_salary desc) as salary_rank
from salary_survey_1) ranked_salary
where salary_rank=1 order by total_salary desc;
select country,job_title,total_salary,rank() over (partition by country order by total_salary desc) as salary_rank
from salary_survey_1;#subquery

#7 Average Salary by City and Industry
select city,industry,avg(total_salary/ExchangeRate) as avg_salary from salary_survey_1 
inner join exchangerates on salary_survey_1.currency=exchangerates.currency
group by city,industry
order by avg_salary desc;

#8Percentage of Employees with Additional Monetary Compensation by Gender
select gender,count(gender) as tcount,count(case when compensation>0 then 1 end)*100/count(*) as percentage_of_employee 
from salary_survey_1 
group by gender;

#9.Total Compensation by Job Title and Years of Experience
select job_title,total_salary/ExchangeRate as total_salary,overall_experience
from salary_survey_1 
join exchangerates on salary_survey_1.currency=exchangerates.currency
;

#10.Average Salary by Industry, Gender, and Education Level
select industry,gender,education,avg(total_salary/ExchangeRate) as avg_salary
from salary_survey_1 join exchangerates
on salary_survey_1.currency=exchangerates.currency
group by industry,gender,education
order by avg_salary desc;